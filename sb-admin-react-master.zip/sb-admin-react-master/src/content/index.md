---
title: React.js Starter Kit
component: ContentPage
---
### Runtime Components

[React](https://facebook.github.io/react/) - A JavaScript library for building user interfaces, developed by Facebook

[Flux](http://facebook.github.io/flux/) - Application architecture for building user interfaces

### Development Tools

[Webpack](http://webpack.github.io/) - Compiles front-end source code into modules / bundles

[BrowserSync](http://www.browsersync.io/) - A lightweight HTTP server for development

### Fork me on GitHub

[github.com/kriasoft/react-starter-kit](https://github.com/kriasoft/react-starter-kit)
