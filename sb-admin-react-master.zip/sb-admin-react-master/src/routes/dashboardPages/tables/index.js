import React from 'react';
import Table from './Table';

export default {

  path: '/table',

  action() {
    return <Table />;
  },

};
