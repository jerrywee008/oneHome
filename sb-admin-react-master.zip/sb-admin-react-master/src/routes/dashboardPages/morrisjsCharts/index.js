
import React from 'react';
import MorrisjsCharts from './MorrisjsCharts';

export default {

  path: '/morrisjscharts',

  action() {
    return <MorrisjsCharts />;
  },

};
