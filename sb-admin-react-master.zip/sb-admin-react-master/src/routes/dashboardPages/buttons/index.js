import React from 'react';
import Button from './Button';

export default {

  path: '/button',

  action() {
    return <Button />;
  },

};
