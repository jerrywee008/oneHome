
import React from 'react';
import Forms from './forms';

export default {

  path: '/forms',

  action() {
    return <Forms />;
  },

};
