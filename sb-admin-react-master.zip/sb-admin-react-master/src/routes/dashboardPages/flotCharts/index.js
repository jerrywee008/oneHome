import React from 'react';
import FlotCharts from './FlotCharts';

export default {

  path: '/flotcharts',

  action() {
    return <FlotCharts />;
  },

};
